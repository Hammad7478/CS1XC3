/**
 * @file course.h
 * @author Hammad Rehman
 * @date 2022-04-10
 * @brief Includes Course type and course functions
 */ 
#include "student.h"
#include <stdbool.h>
/**
* @brief Course struct type that stores different information about a course.
* Course type stores:
* - A course name
* - Course code 
* - Total number of students
* - Students array 
* - Number of students.
*/
typedef struct _course 
{
  char name[100];/**< the course's name */
  char code[10];/**< the course id */
  Student *students;/**< a student of the Student type */
  int total_students;/**< the total number of students enrolled in the course*/
} Course;

/** @brief Functions for enrolling students, printing courses, getting the highest average grade student and getting the number of students passing in a course. */
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


