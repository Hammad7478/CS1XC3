/**
 * @file student.h
 * @author Hammad Rehman
 * @date 2022-04-10
 * @brief Includes Student type and student functions
 */ 

/**
* @brief Student struct type that stores different information about a student.
* Student type stores:
* - A student's first name
* - A student's last name
* - A student's ID
* - A student's grades array
* - A student's number of grades
*/
typedef struct _student 
{ 
  char first_name[50];/**< the student's first name */
  char last_name[50];/**< the student's last name */
  char id[11];/**< the student's id number */
  double *grades; /**< the student's grades */
  int num_grades; /**< the amount of grades a student has */
} Student;
/** @brief Functions for adding grades, finding the average, printing a specific student and creating a new randomly generated student. */
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
