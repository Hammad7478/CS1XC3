/**
 * @file student.c
 * @author Hammad Rehman
 * @date 2022-04-10
 * @brief Library for adding grades, finding the average, printing students and generating random students.
 * 
 * This library contains functions that can do the following tasks:
 * 
 * - add_grade: Adds a grade to a specified student.
 * - average: Returns the average grade of a specified student.
 * - print_student: Prints the information of a specified student.
 * - generate_random_student: Generates a random student.
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"


/** 
 * @brief Adds a grade to a specified student.
 * @param student a custom student type which will be used to add a grade to.
 * @param grade a double type which will be added to the student's grades.
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;//Increasing the number of grades for the specified student by 1.
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));//If this is the student's first grade
  else//If this is not the student's first grade
  {
    student->grades = //Reallocating memory for the grades array in the student type to store all grades.
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;//Adding the grade to the grades array in the student type.
}


/** 
 * @brief Returns the average grade of a specified student.
 * @param student a custom student type which will be used to find the average grade.
 * @return a double type which is the average grade of a specified student.
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;//If the student has no grades, return 0.

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];//Find the total sum of all grades.
  return total / ((double) student->num_grades);//Return the average of all grades.
}


/** 
 * @brief Prints the information of a specified student.
 * @param student a custom student type which will be used to print the information.
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);//Printing the student's name.
  printf("ID: %s\n", student->id);//Printing the student's ID.
  printf("Grades: ");//Printing the student's grades.
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);//Printing ALL the grades.
  printf("\n");
  printf("Average: %.2f\n\n", average(student));//Printing the student's average grade.
}


/** 
 * @brief Generates a random student.
 * @param grades an integer type that contains the number of grades the random student should have
 * @return a random student of the student type.
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  //Set the first and last name of the new student with a random first/last name from the two arrays.
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //Set the ID of the new student with a random series of numbers.
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++)//For loop used to add random grades for the new student.
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;//Return the new student.
}