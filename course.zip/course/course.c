/**
 * @file course.c
 * @author Hammad Rehman
 * @date 2022-04-10
 * @brief Library for enrolling students, printing courses and getting specific
 * student information from courses.
 * 
 * This library contains functions that can do the following tasks:
 * 
 * - enroll_students: enrolls a specified student into a specified course
 * - print_course: prints the information of a specified course.
 * - top_student: returns the student with the highest average grade in a specified course.
 * - passing: returns the number of students passing in a specified course.
 */ 

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 


/** 
 * @brief Enrolls a specified student into a specified course.
 * @param course a specified course which the student will be enrolled into.
 * @param student a custom student type which will be added to the course type.
 */

void enroll_student(Course *course, Student *student)
{
  //Increasing the total number of students in the specified course by 1.
  course->total_students++;
  if (course->total_students == 1) //Checking if this is the first student in the course
  {
    //Allocating memory for the students array in the course type.
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      //Reallocating memory for the students array in the course type to store all students.
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  //Copying the student into the students array in the course type.
  course->students[course->total_students - 1] = *student;
}


/** 
 * @brief Prints all the information contained in the specific course type.
 * @param course a specified course while will be used to extract information to print from.
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);//Printing the name of the course
  printf("Code: %s\n", course->code);//Printing the code of the course
  printf("Total students: %d\n\n", course->total_students);//Printing the total number of students in the course
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);//Printing all the students in the course
}


/** 
 * @brief Returns the student with the highest average grade in a specified course.
 * @param course a specified course while will be used to extract information from.
 * @return a student type which has the highest average grade in the specified course.
 */
Student* top_student(Course* course)
{
  //Covering the case of if the course has no students.
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  //Set max_average to the average of the first student in the course.
  double max_average = average(&course->students[0]);
  //Set student to the first student in the course.
  Student *student = &course->students[0];
 
  //For loop and if statement used to find the student with the highest average grade.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    //If a student's average is higher than the maximum average, then max_average equals
    //to that student's average and the student is set to that student.
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;//Returning the student with the highest average grade in the course.
}


/** 
 * @brief Returns the number of students who are passing in a specified course.
 * @param course a specified course while will be used to extract information from.
 * @param total_passing a pointer thats used to store the number of students passing the course
 * @return passing - A list containing the students that are passing the course.
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;//Counting the number of students passing the course.
  
  //Allocating memory for the passing array with the size of the number of students passing the course.
  passing = calloc(count, sizeof(Student));

  int j = 0;//Used to keep track of the index of each student in the passing array.
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];//Storing the students that are passing into the passing array
      j++; 
    }
  }

  *total_passing = count;//Stores the number of students passing the course.

  return passing; //Returning the list of students passing the course.
}