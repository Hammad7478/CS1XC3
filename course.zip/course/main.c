/**
 * @mainpage Courses function demonstration
 * @file main.c
 * @author Hammad Rehman
 * @date 2022-04-10
 * @brief Runs demonstration code for creating courses.
 * 
 */ 
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  srand((unsigned) time(NULL));

  //Initialize course struct called MATH101 using calloc with the size of Course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //Enroll 20 students into MATH101 using the enroll_student function from course.c
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //Find the student with the highest average grade in MATH101 using the top_student function from course.c
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);//Print the student with the highest average grade in MATH101

  //Find the number of students passing in MATH101 using passing function from course.c
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");//Print the students passing in MATH101
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}